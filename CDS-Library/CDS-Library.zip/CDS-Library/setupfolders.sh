#!/bin/bash

# pass in the folder in which you'd like to create the structure for
echo "Create Folder Structure for $1"

mkdir $1
mkdir $1/R4
mkdir $1/R4/resources
mkdir $1/R4/files
mkdir $1/STU3
mkdir $1/STU3/resources
mkdir $1/STU3/files

